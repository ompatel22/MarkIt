package com.example.attendanceapp;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class SheetActivity extends AppCompatActivity {
    private ListView sheetList;
    private ArrayAdapter adapter;
    private ArrayList<String> listItems = new ArrayList<>();
    private long cid;
    Toolbar toolbar;
    private TextView subtitle;
    private String className, subjectName;
    private MyCalender calender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sheet);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Intent intent = getIntent();
        className = intent.getStringExtra("class");
        subjectName = intent.getStringExtra("sub");

        cid = getIntent().getLongExtra("cid", -1);
        loadListItems();  // Load list items before setting the adapter
        sheetList = findViewById(R.id.sl);

        // Initialize the adapter only after loading the list items
        adapter = new ArrayAdapter(this, R.layout.sheet_list, R.id.date_list_item, listItems);
        sheetList.setAdapter(adapter);

        sheetList.setOnItemClickListener((parent, view, position, id)->openSheetActivity(position));

        //setToolbar();
    }
//    private void setToolbar() {
//        toolbar = findViewById(R.id.toolbar);
//        TextView title = toolbar.findViewById(R.id.title_toolbar);
//        subtitle = toolbar.findViewById(R.id.subtitle_toolbar);
//
//        ImageButton back = toolbar.findViewById(R.id.back);
//
//        title.setText(className);
//        subtitle.setText(subjectName+"  |  "+calender.getDate());
//
//        back.setOnClickListener(v -> onBackPressed());
//
//        toolbar.inflateMenu(R.menu.student_menu);
//    }

    private void openSheetActivity(int position) {
        long[] idArray=getIntent().getLongArrayExtra("idArray");
        int[] rollArray=getIntent().getIntArrayExtra("rollArray");
        String[] nameArray=getIntent().getStringArrayExtra("nameArray");
        Intent intent=new Intent(this,SheetNewActivity.class);
        intent.putExtra("idArray",idArray);
        intent.putExtra("rollArray",rollArray);
        intent.putExtra("nameArray",nameArray);
        intent.putExtra("month",listItems.get(position));
        startActivity(intent);
    }

    private void loadListItems() {
        Cursor cursor = new DBHelper(this).getDistinctMonths(cid);

        if (cursor != null) {
            while (cursor.moveToNext()) {
//                // Safely get the column index and check for valid index
//                int columnIndex = cursor.getColumnIndex(DBHelper.DATE_KEY);
//                if (columnIndex != -1) {
//                    String date = cursor.getString(columnIndex);
//                    // Add the date to the list after processing it
//                    listItems.add(date.substring(3)); // Adjust this based on your date format
//                } else {
//                    // Log if the column index is invalid
//                    Log.e("SheetActivity", "Column index for DATE_KEY is invalid");
//                }
                String date=cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.DATE_KEY));
                listItems.add(date.substring(3));
            }
            cursor.close(); // Always close the cursor to avoid memory leaks
        } else {
            Log.e("SheetActivity", "Cursor is null");
        }
    }
}
